

<?php $__env->startSection('content'); ?>
  <div class="homepage">
    <div class="banner swiper-container">
      <div class="swiper-wrapper">
        <?php for($i = 0; $i < 5; $i++): ?>
          <div class="swiper-slide">
            <figure><img src="<?php echo e(asset('img/slide.png')); ?>" alt=""></figure>
          </div>
        <?php endfor; ?>
      </div>

      <div class="swiper-pagination"></div>
    </div>

    <div class="search-zone container">
      <div class="search-head">
        <div class="left">
          <p class="active">ค้นหาเบอร์</p>
          <p>เบอร์จากความหมาย <label class="number">74</label></p>
          <p>ทำนายเบอร์</p>
        </div>
        <div class="right">
          <div class="manual">คู่มือการใช้งานค้นหาเบอร์ <i class="fas fa-book"></i></div>
        </div>
      </div>
      <div class="search-box">
        <div class="ber-interest box-border">
          <div class="left">
            <p><i class="fas fa-sim-card"></i> ค้นหาเบอร์ที่คุณสนใจ</p>
            <p class="sub">กรอกหมายเลขเบอร์ที่คุณสนใจให้ครบถ้วน</p>
          </div>
          <div class="right">
            <div class="input-ber">
              <input type="number" class="num" id="num1">
              <input type="number" class="num" id="num2">
              <input type="number" class="num" id="num3">
              <div class="keed"></div>
              <input type="number" class="num" id="num4">
              <input type="number" class="num" id="num5">
              <input type="number" class="num" id="num6">
              <div class="keed"></div>
              <input type="number" class="num" id="num7">
              <input type="number" class="num" id="num8">
              <input type="number" class="num" id="num9">
              <input type="number" class="num" id="num10">
            </div>
            <div class="random-ber">
              <button class="form-component button bg"><i class="fas fa-sync-alt"></i> สุ่มหมายเลข</button>
            </div>
          </div>
        </div>

        <div class="berlike-unlike box-border">
          <div class="left">
            <p class="blue"><i class="fas fa-heart"></i> หมายเลขที่คุณชื่นชอบ</p>
            <p class="sub">เลือกตัวเลขที่คุณชื่นชอบ</p>
            <p class="yellow"><i class="fas fa-heart-broken"></i> หมายเลขที่คุณไม่ชอบ</p>
            <p class="sub">เลือกตัวเลขที่คุณไม่ชอบ</p>
          </div>
          <div class="right">
            <div class="input-ber like">
              <div class="num" onclick="click_likenum(this)">0</div>
              <div class="num" onclick="click_likenum(this)">1</div>
              <div class="num" onclick="click_likenum(this)">2</div>
              <div class="num" onclick="click_likenum(this)">3</div>
              <div class="num" onclick="click_likenum(this)">4</div>
              <div class="num" onclick="click_likenum(this)">5</div>
              <div class="num" onclick="click_likenum(this)">6</div>
              <div class="num" onclick="click_likenum(this)">7</div>
              <div class="num" onclick="click_likenum(this)">8</div>
              <div class="num" onclick="click_likenum(this)">9</div>
            </div>
            <div class="input-ber unlike">
              <div class="num" onclick="click_likenum(this)">0</div>
              <div class="num" onclick="click_likenum(this)">1</div>
              <div class="num" onclick="click_likenum(this)">2</div>
              <div class="num" onclick="click_likenum(this)">3</div>
              <div class="num" onclick="click_likenum(this)">4</div>
              <div class="num" onclick="click_likenum(this)">5</div>
              <div class="num" onclick="click_likenum(this)">6</div>
              <div class="num" onclick="click_likenum(this)">7</div>
              <div class="num" onclick="click_likenum(this)">8</div>
              <div class="num" onclick="click_likenum(this)">9</div>
            </div>
          </div>
        </div>

        <div class="ber-cate box-border">
          <div class="left">
            <p><i class="fas fa-chart-pie"></i> หมวดหมู่เบอร์</p>
            <p class="sub">เบอร์มงคลเสริมบารมี,เบอร์มงคลเสริมโชคลาภ,และเบอร์อื่นๆอีกมากมาย</p>
          </div>
          <div class="right">
            <div class="cate-select">
              <select name="" id="" class="form-component select" placeholder="กรุณาเลือกหมวดหมู่เบอร์">
                <?php for($i = 0; $i < 10; $i++): ?>
                  <option value="">หมวดหมู่<?php echo e($i); ?></option>
                <?php endfor; ?>
              </select>
            </div>
          </div>
        </div>

        <div class="range-price box-border">
          <div class="left">
            <p><i class="fas fa-dollar-sign"></i> ช่วงราคา</p>
            <p class="sub">เลือกช่วงราคาที่คุณต้องการ เพื่อง่ายต่อการค้นหา</p>
          </div>
          <div class="right">
            <div class="price">
              <div class="input-box" data-cur="THB">
                <input type="number" class="form-component input" placeholder="900">
              </div>
              <div class="keed"></div>
              <div class="input-box" data-cur="THB">
                <input type="number" class="form-component input" placeholder="9,000,000">
              </div>
            </div>
            <div class="filter">
              <div class="select-button" onclick="swif_filter(this,'left')">น้อยไปมาก</div>
              <div class="select-button" onclick="swif_filter(this,'right')">มากไปน้อย</div>
              <div class="bg"></div>
            </div>
          </div>
        </div>

        <div class="ber-sum box-border">
          <div class="left">
            <p><i class="fas fa-calculator"></i> ผลรวม</p>
            <p class="sub">พลังเสริมขอเบอร์ยิ่งผลรวมเยอะพลังยิ่งยอดเยี่ยม</p>
          </div>
          <div class="right">
            <div class="sum-select">
              <select name="" id="" class="form-component select" placeholder="กรุณาเลือกผลรวม">
                <?php for($i = 0; $i < 10; $i++): ?>
                  <option value=""><?php echo e($i); ?> : พลังแห่งความสำเร็จจากความมุ่นมั่น</option>
                <?php endfor; ?>
              </select>
            </div>
          </div>
        </div>

        <div class="brand-ber box-border">
          <div class="left">
            <p><i class="fas fa-wifi"></i> เครือข่าย</p>
            <p class="sub">การเลือกเครือข่าย จะทำให้คุณได้เรือข่ายตามที่ต้องการ</p>
          </div>
          <div class="right">
            <div class="brand-select">
              <img src="<?php echo e(asset('img/Dtac.png')); ?>" class="icon-select" alt="">
              <select name="" id="" class="form-component select" placeholder="กรุณาเลือกผลรวม">
                <option value="" data-brand-pic="<?php echo e(asset('img/Dtac.png')); ?>">เครือข่าย Dtac</option>
                <option value="" data-brand-pic="<?php echo e(asset('img/Dtac.png')); ?>">เครือข่าย True</option>
                <option value="" data-brand-pic="<?php echo e(asset('img/Dtac.png')); ?>">เครือข่าย AIS</option>
              </select>
            </div>
          </div>
        </div>

        <div class="brand-ber box-border">
          <div class="left">
            <p><i class="fas fa-star"></i> ชุดตัวเลขโปรด</p>
            <p class="sub">ตัวอย่าง เช่น 123,444,5555</p>
          </div>
          <div class="right">
            <div class="input-box">
              <input type="number" class="form-component input" placeholder="00000">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="confirm-search container">
      <div class="group-button">
        <button class="form-component button gray">ล้างข้อมูล</button>
        <button class="form-component button bg">ค้นหา</button>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('style'); ?>
  <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
  <link rel="stylesheet" href="<?php echo e(asset('css/home.min.css')); ?>">
<?php $__env->stopPush(); ?>
 

<?php $__env->startPush('script'); ?>
  <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

  <script async>
    const swiper = new Swiper('.swiper-container', {
      loop: true,
      pagination: {
        el: '.swiper-pagination',
      },
    });

    // ฟังก์ชั่นกดปุ่มเบอร์ที่ชอบไม่ชอบ
    function click_likenum(that){
      that.classList.toggle('active')
    }

    // ฟังก์ชั่นกดปุ่มเลื่อน filter
    function swif_filter(that,dir){
      let element = that.closest('.filter').querySelector('.bg')
      if(dir === "left"){
        element.classList.remove('swif')
      }
      else if(dir === "right"){
        element.classList.add('swif')
      }
      else{
        console.error('Missing parametor dir');
      }
    }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\during operation\simdd\resources\views/pages/home.blade.php ENDPATH**/ ?>